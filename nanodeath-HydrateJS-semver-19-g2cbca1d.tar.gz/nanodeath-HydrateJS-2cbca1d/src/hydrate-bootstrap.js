require('coffee-script')
module.exports = require('./hydrate.coffee')