#!/bin/bash

coffee -o gen/ -c -w src/